<div style="min-height:400px;height:100%;margin-top:15px;">
<iframe id="buy_frame" name="buy_frame" src="<?php echo esc_url( $iframe_url ); ?>" style="height:90%;width:100%" scrolling="auto">
</iframe>
</div>
